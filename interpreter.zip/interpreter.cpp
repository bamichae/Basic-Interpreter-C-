// Code by Ben Michaels with some parsing function contributions such as getNextSymbol from Jesse Hartloff

#include "Interpreter.h"
#include <stdlib.h>
#include <stack>
#include <queue>
#include <algorithm>


void Interpreter::interpretScript(ifstream& inputFile, ofstream& outputFile)
{

	string lineFromFile;
	int lineNumber = 0;

	while (getline(inputFile, lineFromFile))
	{
		lineNumber++;
		decisionFunct(inputFile, lineFromFile, outputFile);
	}

	// write the result from the return statement of the program into the output file
	//outputFile << "output of the document.write lines";

}


double Interpreter::computeInfix(string rhs)
{

	stack <string> operatorStack;            // stack for holding operators
	queue <string> finalQueue;               //final output
	stack <double> doubleStack;               // stack to hold numerical values
	queue <string> transferQ;                // transfer queue


	while (rhs.size() != 0){
		string temp = getNextSymbol(rhs);

		if (temp == " ")             // if empty symbol do nothing
		{

		}

		else if (temp == "(")          // if open paren, push to operand stack
		{
			operatorStack.push(temp);
		}

		else if (temp == ")")                         
		{
			while (operatorStack.top() != "(")        //while top is not open paren push operator onto queue and pop stack
			{
				finalQueue.push(operatorStack.top());
				operatorStack.pop();
			}
			operatorStack.pop();                      // pop "("
		}

		else if (temp == "-" || temp == "+")         // if plus or minus
		{
			if (operatorStack.empty())
			{


			}

			else if (operatorStack.top() == "-" || operatorStack.top() == "+" || operatorStack.top() == "*" || operatorStack.top() == "/")
			{

				while (!operatorStack.empty() && operatorStack.top() != "(")      // if encounter operators above, push them onto stack b/c same order of precedence
				{
					finalQueue.push(operatorStack.top());
					operatorStack.pop();
				}

			}
			operatorStack.push(temp);                              // push operator 
		}

		else if (temp == "/" || temp == "*")                       // if div or mul
		{
			if (operatorStack.empty())
			{

			}
			else if (operatorStack.top() == "/" || operatorStack.top() == "*")    // if encounter another div or mul, push into queue
			{
				finalQueue.push(operatorStack.top());
				operatorStack.pop();
			}
			operatorStack.push(temp);                                              // push temp
		}

		else if (isNumber(temp))                                  // if it's a number push, push into queue
		{
			finalQueue.push(temp);
		}

		else                                                   // else push whatever is left
		{
			finalQueue.push(temp);
		}

		if (rhs.size() == 0)                                  // if the right hand side is 0, 
		{
			while (!operatorStack.empty())                     // and while the op stack is empty, 
			{
				if (operatorStack.top() == " ")               // if op stack top is " ", pop
					operatorStack.pop();
				finalQueue.push(operatorStack.top());         // push the operator to the queue
				operatorStack.pop();
			}
		}
	}// end while


	/* I was encountering some outputs and after
	 * pounding my head on the keyboard for some time,
	 * I decided to write cases for " ", "", and "\n". It worked.
	 */
	while (!finalQueue.empty())                               
	{
		if (finalQueue.front() == " " || finalQueue.front() == "" || finalQueue.front() == "\n")   
			finalQueue.pop();
		transferQ.push(Queue.front());
		Queue.pop();
	}

	while (!transferQ.empty())    //Tranfer queue so I don't delete original queue
	{
		finalQueue.push(transferQ.front());
		transferQ.pop();
	}
	postFixConversion(finalQueue, doubleStack);    // convert to post fix now
	return doubleStack.top();                       // return the stack
}



void Interpreter::postFixConversion(queue<string>& finalStack, stack<double>& doubleStack)   
{   // Final stack is actually a queue. I changed the data structure because it worked easier for me and is more 
	// efficient than putting in two stack and popping one into another. I would not do this mislabeling in industry. 
	// It's confusing.

	double temp1 = 0;  //temps
	double temp2 = 0;
	double finalTemp = 0;
	string tempString = "";

	while (!finalStack.empty()){

		temp1 = 0;  // resetting temps
		temp2 = 0;
		finalTemp = 0;
		tempString = "";

		if (isNumber(finalStack.front()))     // if the front is a number
		{
			tempString = finalStack.front();  // then the tempstring is the front
			doubleStack.push(strtod(tempString.c_str(), NULL)); // convert the string to a double and push
			strtod(tempString.c_str(), NULL);                    // covert the string to double again-redundant but necessary line
			finalStack.pop();                                    // pop
		}

		else if (finalStack.front() == "/" || finalStack.front() == "*" || finalStack.front() == "+" || finalStack.front() == "-") // if encounter operator
		{

			temp2 = doubleStack.top();      // take stack top
			doubleStack.pop();              // pop

			temp1 = doubleStack.top();     // take stack next top
			doubleStack.pop();             // pop

			if (finalStack.front() == "/")   // if div, divide
				finalTemp = temp1 / temp2;

			else if (finalStack.front() == "*")  // if mul, mul, etc.
				finalTemp = temp1 * temp2;

			else if (finalStack.front() == "+")
				finalTemp = temp1 + temp2;

			else if (finalStack.front() == "-")
				finalTemp = temp1 - temp2;

			doubleStack.push(finalTemp);   // push the final temp onto the stack again
			finalStack.pop();              // pop the final stack
		}

		else {
			doubleStack.push(variableMap[finalStack.front()]);  // if there is a variable, save it in a map for later usage.
			finalStack.pop();                                   // pop queue
		}



	}// end while
}


