//Code primarily by Ben Michaels. Crude frameworks and suggested functions provided by Dr. Jesse Hartloff


#ifndef UNTITLED_INTERPRETER_H
#define UNTITLED_INTERPRETER_H

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <stack>
#include <queue>
#include "UserFunction.h"
#include "Parser.h"

using namespace std;


class UserFunction;
class Interpreter {

private:

    map<string, double> variableMap; // a map of variable names to Variable values

    map<string, UserFunction> functionMap; // a map of user defined functions
                                           // stack to remember nesting of if blocks
	vector<string> functionName;          // vector of function names

public:

	void callFunct();

    void interpretScript(ifstream&, ofstream&);


    double computeInfix(string); // separate function for computing infix notation

	void postFixConversion(queue<string>&, stack<double>&); // convert to postfix

	double saveVar(string&, ofstream& );    //save variable

	void editVar(string&);   // change variable

	void writeFile(string&, ofstream&);  // write to the file

	void functionSave(ifstream&, string&);   // save the function

};


#endif //UNTITLED_INTERPRETER_H

